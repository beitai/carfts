module.exports = {
    NODE_ENV: '"production"',
    BASE_API: '"https://api-sit"',
    APP_ORIGIN: '"https://wallstreetcn.com"'
};
