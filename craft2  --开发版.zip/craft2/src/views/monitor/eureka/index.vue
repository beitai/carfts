<template>
    <iframe src='http://localhost:8761' id='show' width='100%' height="780px" frameborder=0 name='showHere' ></iframe>
</template>