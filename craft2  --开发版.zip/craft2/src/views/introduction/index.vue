<template>
<div class="app-container">
  <div class="wrapper">
    <code>
      AG-Admin之前的版本是小前端的方式去运作的，终于给大家换了一波大前端：AG-Admin2.0版本。
        <ul>
          <!-- <li><a target='_blank' class='lin' href="https://github.com/wxiaoqi/ace-admin">后端github项目地址</a></li>
          <li><a target='_blank' class='lin' href="http://git.oschina.net/geek_qi/ace-security">后端gitchina项目地址</a></li> -->
          <li><a target='_blank' href="http://www.jianshu.com/p/49411bcc7f66">开发平台之组织架构设计</a></li>
          <li><a target='_blank' href="http://www.jianshu.com/p/e0b377c3a375">开发平台之权限设计</a></li> 
        </ul>
      </code>
  </div>
</div>
</template>

<style scoped>
.wrapper {
  width: 800px;
  margin: 30px auto;
}
</style>
