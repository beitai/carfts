module.exports = {
    // 开发环境配置
    NODE_ENV: '"development"',
    BASE_API: '"http://localhost:8080/glory"'
    // BASE_API: '"http://localhost:8765"'
}
