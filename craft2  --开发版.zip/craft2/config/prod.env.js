
// var baseUrl = 'http://123.56.2.28:8765';
module.exports = {
    // 正式环境配置
    NODE_ENV: '"production"',
    BASE_API: '"http://localhost:8080/glory"'  
    // BASE_API: '"http://123.56.2.28:8765"'
};
